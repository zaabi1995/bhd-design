BHD WhatsApp display pictures
Ten designs, 1080 x 1080 PNG, built on the official BHD Printing & Designing mark.
Square image, shown through a circular crop. Gallery: https://design.bhd.om/dp
